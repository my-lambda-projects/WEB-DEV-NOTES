// the div with id "game" 
2020 - 09 - 05 - 16 - 16 - 10. png

//the div with id "tic-tac-toe-board"
2020 - 09 - 05 - 16 - 19 - 47. png


//grid squares numbered
2020 - 09 - 05 - 16 - 35 - 56. png