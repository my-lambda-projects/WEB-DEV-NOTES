window.addEventListener("DOMContentLoaded", (event) => {
  // Your JavaScript goes here...
  
});
