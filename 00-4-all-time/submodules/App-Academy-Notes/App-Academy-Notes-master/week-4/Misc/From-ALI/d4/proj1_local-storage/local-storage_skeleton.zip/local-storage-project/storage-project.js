window.addEventListener("DOMContentLoaded", (event) => {

  // const showCart = () => {

  // };

  // const storeItem = () => {

  // };

  // const removeItem = () => {

  // };

});
