# Intermediate CSS Assessment

Here are some important notes about this test.

1. This test has only one HTML and one CSS file. All tests are visual.
2. Do **NOT** modify the **test.html** file. Only write code in the
   **your-code.css** file.

## Usage

1. Open both the **test.html** and **your-code.css** file in VS Code.
2. Open **test.html** in Google Chrome.
3. Make changes to the **your-code.css** file following the directions until
   the targeted elements look like the provided images.
4. Practice! Practice! Practice!
