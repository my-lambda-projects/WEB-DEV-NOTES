# INHERITANCE
#
# Define two classes in this file.
#
# The "Employee" class must have no constructor. It can be an empty class.
#
# The "Manager" class should inherit from the "Employee" class. It should have
# an empty constructor. It can be an empty class.

# WRITE YOUR CODE HERE
