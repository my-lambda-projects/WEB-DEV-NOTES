// TODO: Import all of your importing your API util function

// TODO: Set and export a constant for your `RECEIVE_GIFS` action type

// TODO: Write a function that returns your `action` object literal

// TODO: Write a thunk action creator
