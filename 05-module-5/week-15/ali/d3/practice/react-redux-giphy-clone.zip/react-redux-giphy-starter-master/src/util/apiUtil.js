import { apiKey } from '../config';

// TODO: Define and export a `fetchGifs` function to fetch from the Giphy API