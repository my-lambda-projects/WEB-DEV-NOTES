import { combineReducers } from 'redux';
// TODO: Import the `gifsReducer`

export default combineReducers({
  // TODO: Set the `gifs` slice of state to the `gifsReducer`
});
