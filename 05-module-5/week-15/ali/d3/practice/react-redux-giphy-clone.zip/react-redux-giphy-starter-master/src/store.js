// TODO: Import `createStore` from `redux`
// TODO: Import middleware
// TODO: Import `rootReducer`

// TODO: Define a `configureStore` function

// TODO: Export the `configureStore` function
