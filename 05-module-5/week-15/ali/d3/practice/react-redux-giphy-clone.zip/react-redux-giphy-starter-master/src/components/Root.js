import React from 'react';
import App from './App';

const Root = () => (
  <App />
);

export default Root;
