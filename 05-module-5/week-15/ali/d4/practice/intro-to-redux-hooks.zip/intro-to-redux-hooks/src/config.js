export const ipUrl = process.env.REACT_APP_BASEURL || `https://httpbin.org`;
