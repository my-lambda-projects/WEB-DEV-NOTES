// TODO: Import `CREATE_TASK` and `DELETE_TASK` string literal constants

const tasksReducer = (state = {}, action) => {
  // TODO: Freeze the state
  // TODO: Define switch case for routing 'CREATE_TASK' actions and 'DELETE_TASK' actions
};

export default tasksReducer;
