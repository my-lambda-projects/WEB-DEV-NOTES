import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
// TODO: Import the application's Redux store instance
// TODO: Import the `createTask` and `deleteTask` action creator functions

// TODO: Set the `store` to the window
// TODO: Set the `createTask` function to the window
// TODO: Set the `deleteTask` function to the window

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);
