// TODO: Define `CREATE_TASK` constant
// TODO: Define `DELETE_TASK` constant

// TODO: Define `createTask` action creator function

// TODO: Define `deleteTask` action creator function
