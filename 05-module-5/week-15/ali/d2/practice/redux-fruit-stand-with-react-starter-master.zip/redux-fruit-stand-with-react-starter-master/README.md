
# Redux Fruit Stand... with React!

This repo contains a starter project for following along with the "Using Redux
with React" article in the JS/Py curriculum.
