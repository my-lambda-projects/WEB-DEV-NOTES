export const PURCHASE_CARD = 'PURCHASE_CARD';

export const purchaseCard = (card) => ({
	type: PURCHASE_CARD,
	card
});
