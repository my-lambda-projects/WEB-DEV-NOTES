import React, { Component } from 'react';
import styles from './SinglePost.module.css';

class SinglePost extends Component {
  render() {
    return (
      <div className={styles.singlePost}>
        <h1>SinglePost</h1>
      </div>
    );
  }
}
export default SinglePost;
