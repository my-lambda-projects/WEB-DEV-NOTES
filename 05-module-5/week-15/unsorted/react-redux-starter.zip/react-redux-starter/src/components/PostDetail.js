import React from 'react';
const PostDetail = ({ title }) => {
  return <li>{title}</li>;
};
export default PostDetail;
