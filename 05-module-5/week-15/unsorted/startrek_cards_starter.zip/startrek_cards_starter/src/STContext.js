import React from 'react';

const STContext = React.createContext({});

export default STContext;