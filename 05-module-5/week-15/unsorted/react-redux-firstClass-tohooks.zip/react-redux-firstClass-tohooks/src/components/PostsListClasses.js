// import React, { Component } from 'react';

// import PostDetail from './PostDetail';

// class PostList extends Component {
//   // async componentDidMount() {
//   //   await this.props.postsFetch();
//   // }

//   render() {
//     return (
//       <>
//         <ol>
//           {this.props &&
//             this.props.posts.map(({ title, id }) => (
//               <PostDetail key={id} title={title} />
//             ))}
//         </ol>
//       </>
//     );
//   }
// }

// mapStateToProps = (state) => {
//   return {
//     posts: state.postReducer
//   };
// };

// export default connect(mapStateToProps)(PostList);
