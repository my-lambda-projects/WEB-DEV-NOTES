// import PostManager from './PostManager';
// import { connect } from 'react-redux';

// import { postAdd, postsFetch } from '../reducers/postReducer';

// const mapStateToProps = (state) => {
//   return {
//     posts: state.postReducer
//   };
// };

// const mapDispatchToProps = (dispatch) => {
//   return {
//     postAdd: (post) => dispatch(postAdd(post)),
//     postsFetch: () => dispatch(postsFetch())
//   };
// };

// export default connect(mapStateToProps, mapDispatchToProps)(PostManager);
