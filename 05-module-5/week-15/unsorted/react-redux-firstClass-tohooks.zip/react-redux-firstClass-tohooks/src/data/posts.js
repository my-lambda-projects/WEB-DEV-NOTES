export const posts = [
  {
    id: 1,
    userId: 201,
    title: 'Gilligans Island. Is it true?',
    body:
      'The first mate and his Skipper too will do their very best to make the others comfortable in their tropic island nest. Michael Knight a young loner on a crusade to champion the cause of the innocent. The helpless. The powerless in a world of criminals who operate above the law. Here he comes Here comes Speed Racer. A demon on wheels.'
  },
  {
    id: 2,
    userId: 202,
    title: 'A Baseball Moment',
    body:
      'Baseball ipsum dolor sit amet cellar rubber win hack tossed. Slugging catcher slide bench league, left fielder nubber. Bullpen blue run rotation relief pitcher grass umpire. Forkball bullpen suicide squeeze club bush league field sport. Base cookie triple play blue hot dog relay rake starting pitcher inning.'
  },
  {
    id: 3,
    userId: 203,
    title: 'Poke Moment',
    body:
      'Bulbasaur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ivysaur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Venusaur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Charmander Lorem ipsum dolor sit amet, consectetur adipiscing elit. Charmeleon Lorem ipsum dolor sit amet, consectetur adipiscing elit'
  },
  {
    id: 4,
    userId: 204,
    title: 'Cool Cats',
    body:
      'Chase ball of string eat plants, meow, and throw up because I ate plants going to catch the red dot today going to catch the red dot today. I could pee on this if I had the energy. Chew iPad power cord steal the warm chair right after you get up for purr for no reason leave hair everywhere, decide to want nothing to do with my owner today.'
  },

  {
    id: 5,
    userId: 205,
    title: 'Why Am I At Home',
    body:
      'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex esse laboriosam officia accusantium veritatis fugiat exercitationem vero autem nihil aliquid ullam recusandae, quis odit odio voluptates explicabo nobis! Consequuntur, aliquam? '
  }
];
