import React from 'react';
import Profile from './Profile';

const Home = () => (
  <div id="home">
    <Profile />
  </div>
);

export default Home;
